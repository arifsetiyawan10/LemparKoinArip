package com.abc.lemparkoinarifxtyn;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;

public class LemparKoin extends Activity implements View.OnClickListener {
    private Button buttonUncalna;
    private Button buttonManing;
    private Button buttonMethu;
    private Random acak;
    private ImageView iw;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        acak= new Random();
        setContentView(R.layout.activity_lomparkoin);
        buttonUncalna=(Button)findViewById(R.id.buttonuncalna);
        buttonManing=(Button)findViewById(R.id.buttonmaning);
        buttonMethu=(Button)findViewById(R.id.buttonmethu);
        buttonUncalna.setOnClickListener(this);
        buttonManing.setOnClickListener(this);
        buttonMethu.setOnClickListener(this);
        iw= findViewById(R.id.imageView1);
        iw.setImageResource(R.drawable.question);

    }

    @Override
    public void onClick(View view) {

        if (view==buttonUncalna) {

            Log.d("CLICK_EVENT", "Uncal button diclick");
            TextView tw=(TextView)findViewById(R.id.textView1);
            ImageView iw=(ImageView)findViewById(R.id.imageView1);

            if (acak.nextDouble() < 0.5){
                tw.setText("Kepala");
                iw.setImageResource(R.drawable.head);

            } else {
                tw.setText("Cross");
                iw.setImageResource(R.drawable.tail);
            }

            buttonUncalna.setVisibility(View.INVISIBLE);
            buttonManing.setVisibility(View.VISIBLE);
            buttonMethu.setVisibility(View.VISIBLE);

        }

        else if (view==buttonManing){

            TextView tw=(TextView)findViewById(R.id.textView1);
            ImageView iw=(ImageView)findViewById(R.id.imageView1);

            buttonUncalna.setVisibility(View.VISIBLE);
            buttonManing.setVisibility(View.INVISIBLE);
            buttonMethu.setVisibility(View.INVISIBLE);
        }

        else if (view==buttonMethu){
            this.finish();
        }
    }

}
